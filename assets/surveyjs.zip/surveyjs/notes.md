[old surveyjs](<?= base_url() ?>assets/surveyjs/1.9.48/survey.ko.min.js) 
replace <?= base_url() ?>assets/surveyjs/1.9.48 with <?= base_url() ?>assets/surveyjs/1.9.48

[New Survey Build](https://github.com/surveyjs/builds/tree/master/1.8.9)

[Duplicate notiyf](https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css)

[New survey](https://cdnjs.cloudflare.com/ajax/libs/survey-knockout/1.9.48/survey-creator.min.js)

survey.ko.min.js survey-creator.min.js

### Folder Structure supposed to be 1.8.9 not 1.9.48

<link href="<?= base_url() ?>assets/surveyjs/1.9.48/survey.analytics.datatables.min.css" type="text/css" rel="stylesheet" />
<script src="<?= base_url() ?>assets/surveyjs/1.9.48/survey.analytics.datatables.min.js"></script>
<script src="<?= base_url() ?>assets/surveyjs/1.9.48/survey.core.min.js"></script>
<script src="<?= base_url() ?>assets/surveyjs/1.9.48/surveyjs-widgets.min.js"></script>